package com.game.App;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import org.junit.jupiter.api.Test;

import com.game.controller.GameController;

class BattleShipGameTest {

	@Test
	void BattleShipGameAppTest() throws Exception {
		BattleShipGame battleShipGame = new BattleShipGame();
		assertTrue(battleShipGame.executeMainSimulation(), "Failed to execute Game simulation");
	}

	@Test
	void BadArenaSizeTest() throws Exception {
		GameController controller = new GameController();

		String output = controller.initGame(1);
		String expected = "Unable to create the game";
		assertTrue(output.contains(expected), "Expected [" + expected + "] but got [" + output + "]");
	}

	@Test
	void StartGameFailureTest() throws Exception {
		GameController controller = new GameController();

		controller.initGame(4);
		String output = controller.startGame();
		String expected = "Unable to start the game";
		assertTrue(output.contains(expected), "Expected [" + expected + "] but got [" + output + "]");
	}

	@Test
	void AddShipOutsideArenaTest() throws Exception {
		GameController controller = new GameController();

		controller.initGame(4);
		String output = controller.addShip("SH1", 2, 5, 5, 9, 9);
		String expected = "Unable to add the ships";
		assertTrue(output.contains(expected), "Expected [" + expected + "] but got [" + output + "]");
	}

	@Test
	void PlayerBInvalidShipTest() throws Exception {
		GameController controller = new GameController();

		controller.initGame(5);
		String output = controller.addShip("SH1", 1, 1, 1, 1, 2);
		String expected = "Unable to add the ships";
		assertTrue(output.contains(expected), "Expected [" + expected + "] but got [" + output + "]");
	}

	@Test
	void TestForCodeCoverage() throws Exception {
		GameController controller = new GameController();

		try (BufferedReader br = new BufferedReader(
				new InputStreamReader(getClass().getResourceAsStream("/game_scenarios.csv")))) {

			br.lines().filter(line -> !line.startsWith("#") && !line.trim().isEmpty()) // ignore comments/blank
					.forEach(line -> {
						String[] parts = line.split(",");
						String action = parts[0].trim();

						String output = null;

						switch (action) {
						case "initGame":
							output = controller.initGame(Integer.parseInt(parts[1].trim()));
							break;
						case "addShip":
							output = controller.addShip(parts[1].trim(), Integer.parseInt(parts[2].trim()),
									Integer.parseInt(parts[3].trim()), Integer.parseInt(parts[4].trim()),
									Integer.parseInt(parts[5].trim()), Integer.parseInt(parts[6].trim()));
							break;
						case "viewBattleField":
							output = String.valueOf(controller.viewBattleField());
							break;
						case "startGame":
							output = controller.startGame();
							break;
						default:
							fail("Unknown action: " + action);
						}

						if (parts.length > 1 && !parts[parts.length - 1].trim().isEmpty()) {
							String expected = parts[parts.length - 1].trim();
							assertTrue(output.contains(expected),
									"Expected [" + expected + "] but got [" + output + "]");
						}
					});
		}
	}
}
