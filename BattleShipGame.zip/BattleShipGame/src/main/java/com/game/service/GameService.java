package com.game.service;

import java.util.ArrayDeque;
import java.util.List;
import java.util.Queue;
import java.util.Random;

import com.game.entity.Cell;
import com.game.entity.Grid;
import com.game.entity.Player;
import com.game.entity.Ship;
import com.game.repository.GameRepository;

public class GameService {
	private final GameRepository gameRepository = new GameRepository();

	public String createGame(List<Player> players, int N) throws RuntimeException {

		if (N < 2) {
			throw new RuntimeException("Arena size has to be more than 1");
		}

		Grid grid = new Grid(N);
		gameRepository.saveGame(players, grid);
		return "success";
	}

	public String addShip(String id, int shipSize, int x_pos_A, int y_pos_A, int x_pos_B, int y_pos_B)
			throws RuntimeException {

		Grid grid = gameRepository.getGrid();
		int gridSize = grid.getGridSize();
		List<Player> players = gameRepository.getPlayers();

		// decrementing each coordinate by one since we have zero indexing for the grid

		x_pos_A--;
		y_pos_A--;
		x_pos_B--;
		y_pos_B--;

		// reversing coordinates here when assigning to i,j because the
		// coordinate plane as reverse positioning compared to grid

		int temp = x_pos_A;
		x_pos_A = y_pos_A;
		y_pos_A = temp;

		temp = x_pos_B;
		x_pos_B = y_pos_B;
		y_pos_B = temp;

		// check for player a
		checkConditions(players.get(0).getPlayerId(), shipSize, x_pos_A, y_pos_A, grid, gridSize);

		// check for player b
		checkConditions(players.get(1).getPlayerId(), shipSize, x_pos_B, y_pos_B, grid, gridSize);

		// assigning ships to both players
		assignShip(players.get(0).getPlayerId(), "A-" + id, shipSize, x_pos_A, y_pos_A, grid, gridSize);
		assignShip(players.get(1).getPlayerId(), "B-" + id, shipSize, x_pos_B, y_pos_B, grid, gridSize);

		return "Ships have been assigned to the designated locations";
	}

	public void checkConditions(String player, int shipSize, int x, int y, Grid grid, int gridSize)
			throws RuntimeException {

		int halfSize = shipSize / 2;
		boolean evenShipSize = (shipSize % 2) == 0;

		// check edge cases

		int minX = x - halfSize + (evenShipSize ? 1 : 0);
		int minY = y - halfSize + (evenShipSize ? 1 : 0);
		int maxX = x + halfSize;
		int maxY = y + halfSize;

		if (minX < 0 || minY < 0 || maxX >= gridSize || maxY >= gridSize) {
			throw new RuntimeException("Invalid Coordinates!, please provide proper coordinates");
		}

		// check enemy region trespass
		if (player.equals("PlayerA") && maxY >= (gridSize / 2)) {
			throw new RuntimeException(
					"Enemy Territory!, PlayerA ship location is crossing into PlayerB territory, please change PlayerA ship coordinates");
		} else if (player.equals("PlayerB") && minY < (gridSize + 1) / 2) {
			throw new RuntimeException(
					"Enemy Territory!, PlayerB ship location is crossing into PlayerA territory, please change PlayerB ship coordinates");
		}

		// check occupancy of the cells
		for (int i = minX; i <= maxX; i++) {
			for (int j = minY; j <= maxY; j++) {
				if (grid.getCell(i, j).isOccupied()) {
					throw new RuntimeException(String.format(
							"Already Occupied!, %s ship location (%d,%d) is already occupied, please give proper coordinates",
							player, j + 1, i + 1));
				}
			}
		}
	}

	public boolean assignShip(String playerId, String id, int shipSize, int x, int y, Grid grid, int gridSize) {

		boolean assignSuccess = true;
		try {
			int halfSize = shipSize / 2;
			boolean evenShipSize = (shipSize % 2) == 0;

			int minX = x - halfSize + (evenShipSize ? 1 : 0);
			int minY = y - halfSize + (evenShipSize ? 1 : 0);
			int maxX = x + halfSize;
			int maxY = y + halfSize;

			for (int i = minX; i <= maxX; i++) {
				for (int j = minY; j <= maxY; j++) {
					grid.getCell(i, j).setOccupiedBy(id);
					grid.getCell(i, j).setOccupied(true);
				}
			}

			// increment player wise ship count and update ship's center location in map

			gameRepository.updateShipCount(playerId, gameRepository.getShipCount(playerId) + 1);
			gameRepository.addShip(Ship.builder().x(x).y(y).size(shipSize).id(id).build());

			gameRepository.updateMaxIdLen(Math.max(gameRepository.getMaxIdLen(), id.length()));
		} catch (Exception e) {
			System.out.println(e.getMessage());
			assignSuccess = false;
		}

		return assignSuccess;
	}

	public void removeShip(String playerId, String id) {

		Grid grid = gameRepository.getGrid();
		Ship ship = gameRepository.getShip(id);

		int shipSize = ship.getSize();

		int x = ship.getX();
		int y = ship.getY();

		int halfSize = shipSize / 2;
		boolean evenShipSize = (shipSize % 2) == 0;

		int minX = x - halfSize + (evenShipSize ? 1 : 0);
		int minY = y - halfSize + (evenShipSize ? 1 : 0);
		int maxX = x + halfSize;
		int maxY = y + halfSize;

		for (int i = minX; i <= maxX; i++) {
			for (int j = minY; j <= maxY; j++) {
				grid.getCell(i, j).setOccupiedBy(null);
				grid.getCell(i, j).setOccupied(false);
			}
		}

		gameRepository.updateShipCount(playerId, gameRepository.getShipCount(playerId) - 1);
		gameRepository.removeShip(ship.getId());
	}

	public void printGridView() {

		Grid grid = gameRepository.getGrid();
		int gridSize = grid.getGridSize();

		int maxLen = gameRepository.getMaxIdLen();
//		for (int i = 0; i < gridSize; i++) {
//			for (int j = 0; j < gridSize; j++) {
//				Cell cell = grid.getCell(i, j);
//				if (cell.isOccupied() && cell.getOccupiedBy() != null) {
//					maxLen = Math.max(maxLen, cell.getOccupiedBy().length());
//				}
//			}
//		}

		int cellWidth = maxLen + 2;

		for (int i = gridSize - 1; i >= 0; i--) {
			for (int j = 0; j < gridSize; j++) {
				Cell cell = grid.getCell(i, j);
				String value = cell.isOccupied() && cell.getOccupiedBy() != null ? cell.getOccupiedBy() : "~";
				System.out.printf("%-" + cellWidth + "s", value);
			}
			System.out.println();
		}
		System.out.println();

	}

	public void startGame() throws RuntimeException {

		try {

			System.out.println("Starting the game...");

			List<Player> players = gameRepository.getPlayers();

			for (Player player : players) {
				if (gameRepository.getShipCount(player.getPlayerId()) == 0) {
					throw new RuntimeException("Ships have not been added for the players");
				}
			}

			Grid grid = gameRepository.getGrid();
			int gridSize = grid.getGridSize();

			Queue<Player> playerQueue = new ArrayDeque<>();
			playerQueue.addAll(players);

			Random rand = new Random();
			StringBuilder builder = new StringBuilder();

			while (true) {
				Player player = playerQueue.poll();
				playerQueue.add(player);

				Player nextPlayer = playerQueue.peek();

				builder.setLength(0);

				builder.append(player.getPlayerId() + "'s turn : ");

				int x = 0;
				int y = 0;

				if (player.getPlayerId().equals("PlayerA")) {
					x = ((gridSize + 1) / 2) + rand.nextInt(gridSize - ((gridSize + 1) / 2));
				} else {
					x = rand.nextInt(gridSize / 2);
				}
				y = rand.nextInt(gridSize);

				builder.append(String.format("Missile fired at (%d, %d) : ", x + 1, y + 1));

				int i = y;
				int j = x;

				if (grid.getCell(i, j).isOccupied()) {
					builder.append("\"Hit\" " + grid.getCell(i, j).getOccupiedBy() + " destroyed : ");
					removeShip(nextPlayer.getPlayerId(), grid.getCell(i, j).getOccupiedBy());
				} else {
					builder.append("\"Miss\" : ");
				}

				builder.append("Ships remaining - ");

				boolean gameOver = false;

				for (Player p : players) {
					if (grid.getShipCount().get(p.getPlayerId()) == 0) {
						gameOver = true;
					}
					builder.append(p.getPlayerId() + ":" + grid.getShipCount().get(p.getPlayerId()) + ", ");
				}

				builder.setLength(builder.length() - 2);

				System.out.println(builder.toString());

				if (gameOver) {
					System.out.println("GameOver. " + player.getPlayerId() + " wins!!");
					break;
				}

				Thread.sleep(400);
			}
		} catch (InterruptedException e) {
			System.out.println("Game interrupted due to server error, please restart");
		}
	}

}
