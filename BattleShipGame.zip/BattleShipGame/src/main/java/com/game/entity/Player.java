package com.game.entity;

import lombok.Builder;
import lombok.Data;
import lombok.Generated;

@Data
@Builder
@Generated
public class Player {
	private String playerId;
}
