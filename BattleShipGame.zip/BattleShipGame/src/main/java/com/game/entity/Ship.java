package com.game.entity;

import lombok.Builder;
import lombok.Data;
import lombok.Generated;

@Data
@Builder
@Generated
public class Ship {
	private int x;
	private int y;
	private int size;
	private String id;
}
