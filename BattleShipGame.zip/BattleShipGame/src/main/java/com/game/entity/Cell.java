package com.game.entity;

import lombok.Builder;
import lombok.Data;
import lombok.Generated;

@Generated
@Data
@Builder
public class Cell {
	private int x;
	private int y;
	private boolean occupied;
	private String occupiedBy;
}
