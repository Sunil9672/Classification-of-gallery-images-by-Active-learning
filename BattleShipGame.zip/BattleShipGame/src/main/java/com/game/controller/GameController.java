package com.game.controller;

import java.util.ArrayList;
import java.util.List;

import com.game.entity.Player;
import com.game.service.GameService;

public class GameController {

	private final GameService gameService = new GameService();

	public String initGame(int N) {

		StringBuilder response = new StringBuilder();

		try {

			List<Player> players = new ArrayList<>();
			players.add(Player.builder().playerId("PlayerA").build());
			players.add(Player.builder().playerId("PlayerB").build());

			gameService.createGame(players, N);
			response.append("success");
		} catch (Exception e) {
			response.append("Unable to create the game due to: ");
			response.append(e.getMessage() + "\n");
			response.append("Please try again!");
		}

		return response.toString();
	}

	public String addShip(String id, int size, int x_pos_A, int y_pos_A, int x_pos_B, int y_pos_B) {

		StringBuilder response = new StringBuilder();

		try {
			gameService.addShip(id, size, x_pos_A, y_pos_A, x_pos_B, y_pos_B);
			response.append("success");
		} catch (Exception e) {
			response.append("Unable to add the ships due to: ");
			response.append(e.getMessage() + "\n");
			response.append("Please try again with the correct coordinates and size");
		}

		return response.toString();
	}

	public String startGame() {
		StringBuilder response = new StringBuilder();

		try {
			gameService.startGame();
			response.append("Hope You Enjoyed it!!!");
		} catch (Exception e) {
			response.append("Unable to start the game due to: ");
			response.append(e.getMessage() + "\n");
		}

		return response.toString();
	}

	public boolean viewBattleField() {
		gameService.printGridView();

		return true;
	}

}
