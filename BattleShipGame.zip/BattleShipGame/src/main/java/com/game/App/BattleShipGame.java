package com.game.App;

import com.game.controller.GameController;

public class BattleShipGame {

	public static void main(String[] args) {
		GameController controller = new GameController();

		System.out.println("Welcome! You have now entered the GRAND BATTLESHIP ARENA");

		String msg = controller.initGame(12);

		System.out.println(msg);

		msg = controller.addShip("SH1", 2, 2, 5, 9, 9);

		if (!msg.equals("success")) {
			System.out.println(msg);
		}

		controller.viewBattleField();

		msg = controller.addShip("SH2", 3, 5, 5, 11, 4);
		if (!msg.equals("success")) {
			System.out.println(msg);
		}

		controller.viewBattleField();

		msg = controller.startGame();
		System.out.println(msg);
	}

	public boolean executeMainSimulation() {
		main(null);
		return true;
	}

}
