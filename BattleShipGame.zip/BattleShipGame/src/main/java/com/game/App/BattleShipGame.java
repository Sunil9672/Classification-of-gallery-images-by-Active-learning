package com.game.App;

import com.game.controller.GameController;

public class BattleShipGame {

	public static void main(String[] args) {
		GameController controller = new GameController();

		System.out.println("Welcome! You have now entered the GRAND BATTLESHIP ARENA");
//		System.out.println("Please enter the arena size->");

//		Scanner scanner = new Scanner(System.in);

		String msg = controller.initGame(12);

		System.out.println(msg);

		msg = controller.addShip("SH1", 2, 2, 5, 9, 9);
		System.out.println(msg);
		controller.viewBattleField();

		msg = controller.addShip("SH1", 3, 5, 5, 11, 4);
		System.out.println(msg);

		controller.viewBattleField();

		msg = controller.startGame();
		System.out.println(msg);

//		scanner.close();
	}

	public boolean executeMainSimulation() {
		main(null);
		return true;
	}

}
