package com.game.entity;

import java.util.HashMap;
import java.util.Map;

import lombok.Data;
import lombok.Generated;

@Generated
@Data
public class Grid {
	private Cell[][] grid;
	private int gridSize;
	private Map<String, Ship> shipMap;
	private Map<String, Integer> shipCount;
	private boolean[][] missileFired;
	private int maxIdLen;

	public Grid(int N) {
		gridSize = N;
		grid = new Cell[N][N];
		missileFired = new boolean[N][N];
		
		Cell cell = null;
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				cell = Cell.builder().x(i).y(j).build();
				cell.setX(i);
				cell.setY(j);
				grid[i][j] = cell;
			}
		}

		shipMap = new HashMap<>();
		shipCount = new HashMap<>();
		maxIdLen = 1;
	}

	public Cell getCell(int i, int j) {
		return grid[i][j];
	}

}
