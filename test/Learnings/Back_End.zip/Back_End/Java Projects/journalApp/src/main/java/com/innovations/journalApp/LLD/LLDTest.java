package com.innovations.journalApp.LLD;

public class LLDTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
