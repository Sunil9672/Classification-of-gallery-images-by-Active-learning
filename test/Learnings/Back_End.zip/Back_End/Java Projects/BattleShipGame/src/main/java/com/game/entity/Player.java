package com.game.entity;

import lombok.Builder;
import lombok.Data;
import lombok.Generated;

@Generated
@Data
@Builder
public class Player {
	private String playerId;
}
