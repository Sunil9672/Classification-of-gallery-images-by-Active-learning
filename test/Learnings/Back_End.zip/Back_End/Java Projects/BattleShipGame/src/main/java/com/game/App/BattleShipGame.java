package com.game.App;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.game.controller.GameController;

public class BattleShipGame {
	private static final GameController controller = new GameController();

	public static void main(String[] args) {

		System.out.println("Welcome to the BATTLESHIP ARENA!!!");
		System.out.println("Please enter the commands to begin the game: ");

		Scanner sc = new Scanner(System.in);

		Pattern pattern = Pattern.compile("([a-zA-Z_][a-zA-Z0-9_]*)\\((.*)\\)");

		while (sc.hasNextLine()) {
			String command = sc.nextLine().trim();
			if (!command.isEmpty()) {
				Matcher matcher = pattern.matcher(command);

				if (!matcher.matches()) {
					System.out.println("Invalid command: " + command);
					continue;
				}

				String method = matcher.group(1);
				String paramString = matcher.group(2);

				String[] params = paramString.split("\\s*,\\s*");

				String status = executeMethod(method, params);

				if (!status.equals("success")) {
					System.out.println(status);
				}

				if (method.equals("startGame")) {
					break;
				}
			}
		}

		sc.close();
	}

	public static String executeMethod(String method, String[] params) {

		String outputMessage = "";
		try {
			switch (method) {
			case "initGame": {
				int size = Integer.parseInt(params[0]);
				outputMessage = controller.initGame(size);
				break;
			}

			case "viewBattleField": {
				outputMessage = controller.viewBattleField() ? "success" : "failure";
				break;
			}

			case "addShip": {
				String id = params[0].replace("\"", "");
				int shipSize = Integer.parseInt(params[1]);
				int x_a = Integer.parseInt(params[2]);
				int y_a = Integer.parseInt(params[3]);
				int x_b = Integer.parseInt(params[4]);
				int y_b = Integer.parseInt(params[5]);
				outputMessage = controller.addShip(id, shipSize, x_a, y_a, x_b, y_b);
				break;
			}

			case "startGame": {
				outputMessage = controller.startGame();
				break;
			}

			default: {
				outputMessage = "Invalid Command";
			}
			}

		} catch (Exception e) {
			outputMessage = e.getMessage();
		}

		return outputMessage;
	}

	public boolean executeMainSimulation() {
		String simulationInput = "initGame(12)\n" + "addShip(\"SH1\", 4, 2, 2, 10, 10)\n"
				+ "addShip(\"SH2\", 3, 4, 10, 8, 3)\n" + "viewBattleField()\n" + "startGame()\n";

		System.setIn(new ByteArrayInputStream(simulationInput.getBytes(StandardCharsets.UTF_8)));

		main(null);
		return true;
	}

}
