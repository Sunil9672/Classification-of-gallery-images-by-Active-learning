package com.game.repository;

import java.util.List;
import java.util.Map;

import com.game.entity.Grid;
import com.game.entity.Player;
import com.game.entity.Ship;

public class GameRepository {

	private Grid gridStorage;
	private List<Player> players;

	public void saveGame(List<Player> players, Grid grid) {
		this.gridStorage = grid;
		this.players = players;
	}

	public void saveGrid(Grid grid) {
		this.gridStorage = grid;
	}

	public Grid getGrid() {
		return gridStorage;
	}

	public List<Player> getPlayers() {
		return players;
	}

	public int getShipCount(String playerId) {
		return gridStorage.getShipCount().getOrDefault(playerId, 0);
	}

	public void updateShipCount(String playerId, int count) {

		Map<String, Integer> shipCount = gridStorage.getShipCount();
		shipCount.put(playerId, count);
		gridStorage.setShipCount(shipCount);
	}

	public Ship getShip(String id) {
		return gridStorage.getShipMap().get(id);
	}

	public void addShip(Ship ship) {

		Map<String, Ship> shipMap = gridStorage.getShipMap();
		shipMap.put(ship.getId(), ship);
		gridStorage.setShipMap(shipMap);
	}

	public void removeShip(String shipId) {

		Map<String, Ship> shipMap = gridStorage.getShipMap();
		shipMap.remove(shipId);
		gridStorage.setShipMap(shipMap);
	}

	public void updateMaxIdLen(int len) {
		gridStorage.setMaxIdLen(Math.max(len, gridStorage.getMaxIdLen()));
	}

	public int getMaxIdLen() {
		return gridStorage.getMaxIdLen();
	}

	public boolean getMissileFired(int x, int y) {
		return gridStorage.getMissileFired()[x][y];
	}

	public void updateMissileFired(int x, int y, boolean flag) {
		gridStorage.getMissileFired()[x][y] = flag;
	}
}
